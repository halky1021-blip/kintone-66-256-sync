# kintone-sync
Kintone CLI sync between guest and normal space
